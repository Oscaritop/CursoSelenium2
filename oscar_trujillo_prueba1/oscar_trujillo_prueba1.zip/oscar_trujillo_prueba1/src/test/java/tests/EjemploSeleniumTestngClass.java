package tests;

import org.testng.annotations.Test;

public class EjemploSeleniumTestngClass {
  
  @Test
  public void f() {
  }
}
